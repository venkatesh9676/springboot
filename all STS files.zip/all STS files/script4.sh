echo "enter number 1 or 2 or 3"
read a
if [${a} = "1"];
then
	echo "enter number is $a"
elif [${a} = "2"];
then
	echo "enter number is $a"
elif [${a} = "3"];
then
	echo "enter number is $a"
else 
	echo "invalid number"
fi

