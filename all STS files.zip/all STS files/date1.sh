0 8 1 * * date.sh

