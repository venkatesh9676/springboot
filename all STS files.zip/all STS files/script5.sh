echo "enter numbers a"
read a
echo "enter number b"
read b
echo "addition: "$((a + b));
echo "substraction: "$((a - b));
echo "multiplicatio: "$((a * b));
echo "division: "$((a / b));
