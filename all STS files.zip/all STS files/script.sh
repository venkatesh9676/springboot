 echo "What is your name?"
 read USER_NAME
 echo "Creating a file called ${USER_NAME}_file"
 touch "${USER_NAME}_file"
