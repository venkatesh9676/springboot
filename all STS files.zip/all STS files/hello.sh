0 8 1 * * hello.sh
